#literals and constants
None

a.b.c

True
"ola"
3
5
4 + 7
4 + 7 + 12

a < b
a > b

if a < b:
    print(a)
else:
    print(b)
#assignments
a = 0
b = 1
c = 3
a = True
#identifier
c
b

#double ops
c = 3 + 4 + 17
#unary ops
not True
not a
c = c % 3
c = c ** 3
c = c / 3
c = c * 3
b = False
#boolean ops
a and b
a and True
True or False
a and b or c
#if/else
if a:
    b
else:
    c

#ifs inside ifs
if a or b:
    a
    if a:
        4
    else:
        c
else:
    True

#ifs without else
if not a:
    print("Not a")

while not a:
    a % 2
    a * 7231
    a % a % a
    print("ola", 1 ,a ,3)
    if(a):
        print("ola")

a.b.c()
a.b().c.d(a, c, d)
