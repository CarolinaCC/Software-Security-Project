a = True
b = "ola"
while a:
    b = get()
execute(a)
