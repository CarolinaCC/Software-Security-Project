a = get()
b = "Ola"
while a:
    b = "Ola"
b = "Ola"
execute(b)
