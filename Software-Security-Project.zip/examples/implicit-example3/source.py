a = "Hello World"
while a:
    execute(a)
a = get()
execute(a)
