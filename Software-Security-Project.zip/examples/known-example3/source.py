a = True
a = get()
if  not a or b:
    a = a + "ola"
execute(a)
