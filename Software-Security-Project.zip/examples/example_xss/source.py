request = request.GET.get()
suds.sax.text.Raw(request)