a = True
if  get():
    a = "ola"
execute(a)
