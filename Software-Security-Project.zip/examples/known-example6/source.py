a = True
while  not True:
    a = get()
execute(a)
