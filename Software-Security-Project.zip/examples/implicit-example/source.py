a = get()
b = "Hello"
if a:
    b = "Ola"
execute(b)
