cmd = request.args.get()
os.system(cmd)