name =  request.form.get()
name = MySQLdb.escape_string(name)
suds.sax.text.Raw(request)
