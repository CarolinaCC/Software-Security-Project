uname = copy()
uname2 = ChatMessageForm()
q = mark_safe("SELECT pass FROM users WHERE user='%s'" % uname % uname2 % uname3)
