a = True

if not a:
    a = get()

execute(a)
