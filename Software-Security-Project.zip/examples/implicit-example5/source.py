a = get()
b = "Ola"
while a:
    if a:
        if a:
            if a:
                b = "Ola"
            else:
                b = "Ola2"
        else:
            b = "Ola3"
    else:
        b = "Ola4"
if a:
    b = "Ola5"
else:
    execute(b)
