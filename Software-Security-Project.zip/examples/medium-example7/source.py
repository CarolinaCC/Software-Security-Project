a = "Hello World"
while True:
    raw(a)
    a = mogrify(a)
    a = a + get()
