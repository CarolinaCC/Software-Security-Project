request = request.GET.get()
flask.send_file(request)
