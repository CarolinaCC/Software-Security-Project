a = get()

if a:
    print("ola")
else:
    print("ola")
    
execute(a)
