a = get()
while True:
    raw(a)
raw(a)
