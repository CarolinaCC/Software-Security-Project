uname = mogrify("uname")
q = mark_safe(uname)
