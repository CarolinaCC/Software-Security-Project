a = "Hello World"
while True:
    a = get()
    
raw(a)
