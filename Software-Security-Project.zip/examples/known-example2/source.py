a = True

if  not a or not True:
    a = get()
else:
    execute(b)
execute(a)
