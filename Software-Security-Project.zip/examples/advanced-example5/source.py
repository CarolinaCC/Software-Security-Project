while True:
    a = a + mogrify(a)
    a = execute(a)
    a = a + get()
    if True:
        a = a + get()
        execute(a)
        if False:
            execute(a)
        else:
            execute(b)
    else:
        execute(a)
