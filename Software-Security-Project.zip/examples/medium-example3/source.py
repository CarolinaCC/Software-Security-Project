a = get()
if a:
    mogrify(a)

execute(a)
